<h1 align="center">PrestigeClient</h1>

**Trillium INC: https://discord.gg/vzXzFpv2gk**

# Why?
Still a monkey, lies, and has to pay people so his client even works. The last mod update was on 14.8.2024. Not even mentioning the fact that this was just a fix update (the real update was like a year ago, so y’all didn’t miss much). When I mentioned he keeps lying, I’m talking about the expose I made on him like five months ago, where he got [exposed for his past with logging people](https://youtu.be/c9Ksi4itVF8) (Respect to Kambinq for coming out with undeniable evidence).   

His boyfriend, nsm4 (Skid), blatantly defends him because he doesn’t want to lose him over a Minecraft beef. (nsm4) proceeds to say that I wanted to RAT my client in 2022, which I believe he meant Experium (+-5 people had access, and there were 8 contributors, doesn’t have proof :broken_heart:). He does everything in his power to clear his boyfriend’s name and trash me and Walmart (aka Trillium).   

He (zPiss) uses 2Nick to crack everything and anything he wants cracked (Argon Client was a great example) and simply can’t do anything himself because he’s rendered incompetent. Astonishingly enough, his client, both mod and injection, is [detected by Ocean](https://www.youtube.com/watch?v=cr6jB1qhuYY), even after self-destruct (SelfDestruct itself might actually make it even more detected LMAOOO). So, if you use this client and someone says they’re going to SS you with Ocean, take a deep breath, close the game, and start crying because your favorite fuqing paste client just got detected by a group of monkeys who didn’t know a single EU privacy law until now.   

To this day, zPrestige is one of the biggest jokes known to the community, and people who glaze him are essentially only doing so as a coping mechanism because their favorite injection paste has two modules and crashes on inject (imagine...). Nowadays, it looks like more people in his server are calling his client trash as people are finally starting to realize that they can just rename a few strings in [Argon client](https://github.com/LvStrnggg/argon) and get a 4x better client than this while bypassing SS. Also, he got inside for like 3/4 months and it showed how his personal leachers did 99% of the sh1 for him.

If you want a Pisstige alternative, probably try out [Phantom](https://phantom.pub/) (Not sponsored, not sure if it has CPvP modules) as that actually looks very decent. Also, my own client might be coming out in the next 3 months or so. So no need to worry that there wont be a single good client out there.

# Disclaimer

Config system does not work as it is server-sided and we are not making an emulator for something detected by Ocean.

# Prestige Deleter Usage

https://www.youtube.com/watch?v=yMhXrdtAkrI

# How To Use
1. Download the Fabric installer from here, open it and choose Minecraft 1.20.4 & Latest Fabric Loader
2. Download [Prestige-1.20.4.jar](https://gitlab.com/3000IQPlay/Prestige/-/raw/main/Prestige9-20240814/Prestige-1.20.4.jar?ref_type=heads) from this repository page along with [Fabric API](https://modrinth.com/mod/fabric-api) and [Fabric Kotlin](https://modrinth.com/mod/fabric-language-kotlin) and put them all into your .minecraft/mods folder
3. Start the game (with Fabric)

# Credits
zPrestige (zprestige_) - Developer of the Client.

3000IQPlay & LvStrng - Cracking.

ZKM the master of klass - Jar.

# GUI: (Bind: RShift)

![image](https://gitlab.com/3000IQPlay/Prestige/-/raw/main/Prestige9-20240814/assets/GUI.png?ref_type=heads)

# Acoustic moments <3:

![image]()
